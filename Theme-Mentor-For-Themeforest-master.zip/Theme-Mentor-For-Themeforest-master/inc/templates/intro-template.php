
<h2><?php _e( 'About', 'dx_theme_mentor' ); ?></h2>
<p><?php _e( "Theme mentor for themeforest - helper plugin for themeforest WordPress Themes , the cousin of Theme-Check reporting other possible theme issues.", 'dx_theme_mentor' ); ?></p>
<h2><?php _e( 'Contact', 'dx_theme_mentor' ); ?></h2>
<p><?php printf( __( 'If you have found a bug or would like to make a suggestion or contribution here we are <a href="%1$s">Github</a>.', 'dx_theme_mentor' ), 'https://github.com/Ataurr/Theme-Mentor-For-Themeforest/' ); ?></p>

